import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { FaqsComponent } from './faqs/faqs.component';
import {FaqsService} from './services/faqs.service';
import {HttpClient, HttpClientModule} from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    FaqsComponent
  ],
  imports: [
    BrowserModule,HttpClientModule
  ],
  providers: [FaqsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
