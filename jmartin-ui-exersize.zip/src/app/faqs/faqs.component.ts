import { Component, OnInit } from '@angular/core';
import {FaqsService} from '../services/faqs.service';

@Component({
  selector: 'app-faqs',
  templateUrl: './faqs.component.html',
  styleUrls: ['./faqs.component.scss']
})
export class FaqsComponent implements OnInit {

  private faqs;

  openFaqs = new Set();

  constructor(private faqService: FaqsService) {
    this.faqService.getFAQ().subscribe( data => {
      this.faqs = data;
    });
  }

  ngOnInit() {
  }

  isFaqOpen(id) {
    return this.openFaqs.has(id);
  }

  toggleFaq(id) {
    if (!this.openFaqs.has(id)) {
      this.openFaqs.add(id);
    } else {
      this.openFaqs.delete(id);
    }
  }
}
